<?php
class validaServicio
{
	
	static function validarParametrosCliente($parametros)
	{
		$array=array();

		if(!isset($parametros['placa']) || $parametros['placa'] == ""){
			$array = array("Error"=>"Debe ingresar una placa");
		}

		if(!isset($parametros['clientes_grupo_id']) || $parametros['clientes_grupo_id'] == ""){
			$array = array("Error"=>"Debe ingresar una id del grupo del cliente");
		}

		return $array;

	}

	static function validarPlacasRepetidas($placa, $placa_actual = "")
	{
		$array=array();
		$conn = conexionBD();

		if($placa_actual == $placa){
			return $array;
		}
		$quey_ext = "";
		if($placa_actual !=""){
			$query_ext = " AND placa NOT IN ('".$placa_actual."')";
		}	

		if($placa!=""){
			$sql = "SELECT count(*) AS contador FROM clientes WHERE placa = '".$placa."'".$query_ext;
		}
		$rs = mysql_query($sql,$conn);
		$contador = 0;
		while($row = mysql_fetch_array($rs))
		{
		    $contador = $row['contador'];
		}

		if($contador>0){
			$array = array("Error"=>"Ya se encuentra registrada la placa ".$placa);	
		}

		return $array;


	}


	static function validarGrupoIDExistente($grupoId)
	{

		$array=array();
		$conn = conexionBD();
		if($grupoId!=""){
			$sql = "SELECT count(*) AS contador FROM clientes_grupo WHERE id = '".$grupoId."'";
		}
		$rs = mysql_query($sql,$conn);
		$contador = 0;
		while($row = mysql_fetch_array($rs))
		{
		    $contador = $row['contador'];
		}

		if($contador == 0){
			$array = array("Error"=>"No existe registro del id_grupo_cliente seleccionado -> ".$grupoId);	
		}	

		return $array;

	}

	static function validarParametrosGrupoCliente($parametros)
	{
		$array=array();

		if(!isset($parametros['nombre']) || $parametros['nombre'] == ""){
			$array = array("Error"=>"Debe ingresar un nombre");
		}

		if(!isset($parametros['porcentaje']) || $parametros['porcentaje'] == ""){
			$array = array("Error"=>"Debe ingresar un porcentaje");
		}


		if(!is_numeric($parametros['porcentaje'])){

			$array = array("Error"=>"Debe ingresar un valor numerico entero en porcentaje");	
		}

		return $array;

	}

	static function validarGruposRepetidos($nombre)
	{
		$array=array();
		$conn = conexionBD();
		if($nombre!=""){
			$sql = "SELECT count(*) AS contador FROM clientes_grupo WHERE nombre = '".$nombre."'";
		}
		$rs = mysql_query($sql,$conn);
		$contador = 0;
		while($row = mysql_fetch_array($rs))
		{
		    $contador = $row['contador'];
		}

		if($contador>0){
			$array = array("Error"=>"Ya se encuentra registrado el grupo ".$nombre);	
		}

		return $array;
	}

	static function validarParametrosEdicionCliente($parametros)
	{
		$array=array();

		if(!isset($parametros['placa_actual']) || $parametros['placa_actual'] == ""){
			$array = array("Error"=>"Debe ingresar la placa que actualmente tiene el cliente que se va editar");
		}

		if(!isset($parametros['placa']) || $parametros['placa'] == ""){
			$array = array("Error"=>"Debe ingresar una placa");
		}

		if(!isset($parametros['activo']) || $parametros['activo'] == ""){
			$array = array("Error"=>"Debe ingresar la opcion 1 como activo o 2 para el caso inactivo");
		}

		if($parametros['activo'] !="1" && $parametros['activo'] != "2"){
			$array = array("Error"=>"Debe ingresar la opcion 1 como activo o 2 como inactivo");
		}

		if(!isset($parametros['clientes_grupo_id']) || $parametros['clientes_grupo_id'] == ""){
			$array = array("Error"=>"Debe ingresar una id del grupo del cliente");
		}

		return $array;

	}


	static function validarParametrosEdicionGrupo($parametros)
	{
		$array=array();

		if(!isset($parametros['nombre_actual']) || $parametros['nombre_actual'] == ""){
			$array = array("Error"=>"Debe ingresar el nombre que actualmente tiene el grupo que se va editar");
		}

		if(!isset($parametros['nombre']) || $parametros['nombre'] == ""){
			$array = array("Error"=>"Debe ingresar un nombre");
		}

		if(!isset($parametros['activo']) || $parametros['activo'] == ""){
			$array = array("Error"=>"Debe ingresar la opcion 1 como activo o 2 para el caso inactivo");
		}

		if($parametros['activo'] !="1" && $parametros['activo'] != "2"){
			$array = array("Error"=>"Debe ingresar la opcion 1 como activo o 2 como inactivo");
		}

		return $array;

	}


	static function validarNombreGrupoRepetidos($nombre, $nombre_actual = "")
	{
		$array=array();
		$conn = conexionBD();

		if($nombre_actual == $nombre){
			return $array;
		}
		$quey_ext = "";
		if($nombre_actual !=""){
			$query_ext = " AND nombre NOT IN ('".$nombre_actual."')";
		}	

		if($nombre!=""){
			$sql = "SELECT count(*) AS contador FROM clientes_grupo WHERE nombre = '".$nombre."'".$query_ext;
		}
		$rs = mysql_query($sql,$conn);
		$contador = 0;
		while($row = mysql_fetch_array($rs))
		{
		    $contador = $row['contador'];
		}

		if($contador>0){
			$array = array("Error"=>"Ya se encuentra registrada el nombre del grupo ".$nombre);	
		}

		return $array;


	}


	static function validarParametrosRegistroEntrada($parametros)
	{
		$array=array();

		if(!isset($parametros['placa']) || $parametros['placa'] == ""){
			$array = array("Error"=>"Debe ingresar placa del vehiculo");
		}

		if(!isset($parametros['fecha_entrada']) || $parametros['fecha_entrada'] == ""){
			$array = array("Error"=>"Debe ingresar la fecha de entrada del estacionamiento");
		}


		return $array;

	}

	static function validarCLiente($placa){

		$array=array();
		$conn = conexionBD();
		if($placa!=""){
			$sql = "SELECT clientes.id as cliente_id, grupo.id as grupo_id  FROM clientes INNER JOIN clientes_grupo AS grupo ON grupo.id = clientes.id  WHERE clientes.placa = '".$placa."'";
		}
		$rs = mysql_query($sql,$conn);
		$id = "";
		while($row = mysql_fetch_array($rs))
		{
		    $id = $row['cliente_id'];
		    $array = array('cliente_id'=>$row['cliente_id'],'grupo_id'=>$row['grupo_id']);
		}

		if($id == ""){
			$array = array("Error"=>"No se encuentra registrado en el sistema la placa ".$placa);	
		}

		return $array;

	}


	static function validarRegistroEntradaSalida($idCliente,$registro){

		$array=array();
		$conn = conexionBD();
		if($idCliente!=""){
			$sql = "SELECT count(*) as contador FROM registro_estacionamiento WHERE clientes_id = '".$idCliente."' AND registro_salida IS NULL";
		}
		$rs = mysql_query($sql,$conn);
		$contador = 0;
		while($row = mysql_fetch_array($rs))
		{
		    $contador = $row['contador'];
		}

		if($registro == "entrada"){
			if($contador>0){
				$array = array("Error"=>"No se puede registrar una entrada, debido que no ha registrado la salida");	
			}
		}


		if($registro == "salida"){
			if($contador == 0){
				$array = array("Error"=>"No se puede registrar una salida, debido que no ha registrado la entrada");	
			}
		}
		return $array;

	}


	static function validarParametrosRegistroSalida($parametros)
	{
		$array=array();

		if(!isset($parametros['placa']) || $parametros['placa'] == ""){
			$array = array("Error"=>"Debe ingresar placa del vehiculo");
		}

		if(!isset($parametros['fecha_salida']) || $parametros['fecha_salida'] == ""){
			$array = array("Error"=>"Debe ingresar la fecha de entrada del estacionamiento");
		}


		return $array;

	}

	static function calculoCobroSalida($idGrupo,$idCliente,$fecha_salida)
	{
	
		$array=array();
		$conn = conexionBD();
		if($idGrupo!=""){
			$sql = "SELECT porcentaje FROM clientes_grupo WHERE id = '".$idGrupo."'";
		}
		$rs = mysql_query($sql,$conn);
		$porcentaje = 0;
		while($row = mysql_fetch_array($rs))
		{
		    $porcentaje = $row['porcentaje'];
		}

		$sql2 = "SELECT fecha_entrada FROM registro_estacionamiento WHERE clientes_id = '".$idCliente."' AND registro_entrada = 1 AND fecha_salida IS NULL AND registro_salida IS NULL";
		$rs2 = mysql_query($sql2,$conn);
		$porcentaje = 0;
		while($row2 = mysql_fetch_array($rs2))
		{
		    $fecha_entrada = $row2['fecha_entrada'];
		}

		$horaInicio = new DateTime($fecha_entrada);
		$horaTermino = new DateTime($fecha_salida);

		$interval = $horaInicio->diff($horaTermino);
		$minutosI = $interval->format('%i');
		$horas = $interval->format('%H');
		$minutos = $interval->days * 24 * 60;
		$minutos += $interval->h * 60;
		$minutos += $interval->i;
		if($porcentaje > 0){
			$valor1 = 10 * $horas;
			$cobro = $valor1 - (($porcentaje*$valor1)/100);
		}else{
			if($minutosI>10){
				$horas = $horas + 1;
			} 
			$cobro = 10 * $horas;		
		}

		$array = array('cobro'=>number_format($cobro,2,".",","),'minutos'=>$minutos);
		return $array;

	}


}