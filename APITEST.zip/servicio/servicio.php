<?php
	include("../conexion/conexion.php");
	include("../lib/nusoap.php");
	include("validaServicio.php");
	$url = "http://localhost/APITEST/servicio/servicio.php";
	$server = new nusoap_server();
	$server->configureWSDL("consulta",$url);
	$server->wsdl->schemaTargetNamespace = $url;
	$server->soap_defencoding = "utf-8";
	
	$server->register("obtenerRegistrosClientePlaca",
		array("placa"=>"xsd:string"),
		array("return"=>"xsd:string"),
		$url);

	function obtenerRegistrosClientePlaca($placa)
	{
		$conn = conexionBD();
		if($placa!=""){
			$sql = "SELECT reg.fecha_entrada,reg.fecha_salida,reg.cobro,clientes.placa,grupo.nombre AS grupo from registro_estacionamiento AS reg 
				INNER JOIN clientes ON clientes.id = reg.clientes_id AND clientes.placa =  '".$placa."' 
				INNER JOIN clientes_grupo AS grupo ON grupo.id = clientes.id";
		}
		$array = array('Error'=>'No se encuentra registrado Placa del cliente');
		$rs = mysql_query($sql,$conn);
		while($row = mysql_fetch_array($rs))
		{
			$array[] = $row;
		}
		
		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}

	$server->register("crearRegistrosCliente",
		 array('parametros'=>'xsd:string'),
		array("return"=>"xsd:string"),
		$url);

	function crearRegistrosCliente($parametros)
	{

		$parametros = json_decode($parametros,true);

		$valError = array();
		$valError = validaServicio::validarParametrosCliente($parametros);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}
		$valError = validaServicio::validarPlacasRepetidas($parametros['placa']);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}

		$valError = validaServicio::validarGrupoIDExistente($parametros['clientes_grupo_id']);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}		

		$array = array('Exito'=>'Se ha registrado la placa y grupo correctamente');
		$fecha = date('Y-m-d H:i:s');
		$conn = conexionBD();
		
			$sql = "INSERT INTO clientes (placa, 
				fecha_creacion, 
				fecha_modificacion, 
				activo, 
				clientes_grupo_id) 
				VALUES 
				('".$parametros['placa']."', 
				'".$fecha."', 
				'".$fecha."', 
				'1', 
				'".$parametros['clientes_grupo_id']."')";
		$rs = mysql_query($sql,$conn);
		if (!$rs) {
			$array = array('Error'=>'No registra crearRegistrosCliente');
		
		}
		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}

	$server->register("crearGrupoCliente",
		 array('parametros'=>'xsd:string'),
		array("return"=>"xsd:string"),
		$url);

	function crearGrupoCliente($parametros)
	{

		$parametros = json_decode($parametros,true);

		$valError = array();
		$valError = validaServicio::validarParametrosGrupoCliente($parametros);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}
		$valError = validaServicio::validarGruposRepetidos($parametros['nombre']);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}

		$array = array('Exito'=>'Se ha registrado el grupo correctamente');
		$fecha = date('Y-m-d H:i:s');
		$conn = conexionBD();
		
			$sql = "INSERT INTO clientes_grupo (nombre, 
			activo, porcentaje, 
			fecha_creacion, 
			fecha_modificacion) 
			 VALUES 
			 ('".$parametros['nombre']."', 
			 '1', 
			 '".$parametros['porcentaje']."', 
			 '".$fecha."', 
			'".$fecha."');";
		$rs = mysql_query($sql,$conn);
		if (!$rs) {
			$array = array('Error'=>'No registra crearGrupoCliente');
		
		}
		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}

	$server->register("editarRegistrosCliente",
		 array('parametros'=>'xsd:string'),
		array("return"=>"xsd:string"),
		$url);


	function editarRegistrosCliente($parametros)
	{

		$parametros = json_decode($parametros,true);

		$valError = array();
		$valError = validaServicio::validarParametrosEdicionCliente($parametros);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}
		$valError = validaServicio::validarPlacasRepetidas($parametros['placa'],$parametros['placa_actual']);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}

		$valError = validaServicio::validarGrupoIDExistente($parametros['clientes_grupo_id']);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}		
		$array = array('Exito'=>'Se ha editado la placa y grupo de cliente correctamente');
		$fecha = date('Y-m-d H:i:s');
		$conn = conexionBD();
		
			$sql = "UPDATE clientes 
			SET placa = '".$parametros['placa']."', 
			fecha_modificacion = '".$fecha."', 
			activo = '".$parametros['activo']."', 
			clientes_grupo_id = '".$parametros['clientes_grupo_id']."' 
			WHERE placa = '".$parametros['placa_actual']."'";
		$rs = mysql_query($sql,$conn);
		if (!$rs) {
			$array = array('Error'=>'No edita editarRegistrosCliente');
		
		}
		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}

	$server->register("editarGrupoCliente",
		 array('parametros'=>'xsd:string'),
		array("return"=>"xsd:string"),
		$url);


	function editarGrupoCliente($parametros)
	{

		$parametros = json_decode($parametros,true);

		$valError = array();
		$valError = validaServicio::validarParametrosEdicionGrupo($parametros);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}
		$valError = validaServicio::validarParametrosGrupoCliente($parametros);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}
		$valError = validaServicio::validarNombreGrupoRepetidos($parametros['nombre'],$parametros['nombre_actual']);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}
		$array = array('Exito'=>'Se ha editado el grupo de cliente correctamente');
		$fecha = date('Y-m-d H:i:s');
		$conn = conexionBD();
		
			$sql = "UPDATE clientes_grupo 
			SET nombre = '".$parametros['nombre']."',
			  activo = '".$parametros['activo']."',
			  porcentaje = '".$parametros['porcentaje']."',
			  fecha_modificacion = '".$fecha."' 
			  WHERE nombre = '".$parametros['nombre_actual']."'";
		$rs = mysql_query($sql,$conn);
		if (!$rs) {
			$array = array('Error'=>'No edita editarRegistrosCliente');
		
		}
		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}

	$server->register("crearRegistroEntrada",
		 array('parametros'=>'xsd:string'),
		array("return"=>"xsd:string"),
		$url);
	function crearRegistroEntrada($parametros)
	{

		$parametros = json_decode($parametros,true);

		$valError = array();
		$val = array();
		$valError = validaServicio::validarParametrosRegistroEntrada($parametros);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}

		$val = validaServicio::validarCLiente($parametros['placa']);
		if(isset($val['Error'])){
			return json_encode($val,JSON_UNESCAPED_UNICODE);
		}else{
			$clienteId = $val['cliente_id'];
			$grupoId = $val['grupo_id'];
		}

		$valError = validaServicio::validarRegistroEntradaSalida($clienteId,"entrada");
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}

		$array = array('Exito'=>'Se ha registrado entrada estacionamiento');
		$conn = conexionBD();
		
			$sql = "INSERT INTO registro_estacionamiento (clientes_id,
			 clientes_grupo_id,
			 registro_entrada,
			   fecha_entrada)
			    VALUES (
			    '".$clienteId."', 
			    '".$grupoId."', 
			    '1', 
			    '".$parametros['fecha_entrada']."');";
		$rs = mysql_query($sql,$conn);
		if (!$rs) {
			$array = array('Error'=>'No registra crearRegistroEntrada');
		
		}
		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}


	$server->register("crearRegistroSalida",
		 array('parametros'=>'xsd:string'),
		array("return"=>"xsd:string"),
		$url);
	function crearRegistroSalida($parametros)
	{

		$parametros = json_decode($parametros,true);

		$valError = array();
		$val = array();
		$valError = validaServicio::validarParametrosRegistroSalida($parametros);
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}

		$val = validaServicio::validarCLiente($parametros['placa']);
		if(isset($val['Error'])){
			return json_encode($val,JSON_UNESCAPED_UNICODE);
		}else{
			$clienteId = $val['cliente_id'];
			$grupoId = $val['grupo_id'];
		}

		$valError = validaServicio::validarRegistroEntradaSalida($clienteId,"salida");
		if(isset($valError['Error'])){
			return json_encode($valError,JSON_UNESCAPED_UNICODE);
		}

		$valoresArray = validaServicio::calculoCobroSalida($grupoId,$clienteId,$parametros['fecha_salida']);

		$array = array('Exito'=>'Se ha registrado salida estacionamiento de placa '.$parametros['placa'].' con un cobro de $'.$valoresArray['cobro'].' por un tiempo de '.$valoresArray[
			'minutos'].' minutos');

		$conn = conexionBD();
		$sql = "UPDATE registro_estacionamiento 
		SET registro_salida = '1', 
		fecha_salida = '".$parametros['fecha_salida']."', 
		cobro = '".$valoresArray['cobro']."', 
		clientes_grupo_id = '".$grupoId."',
		minutos = '".$valoresArray['minutos']."'  
		WHERE clientes_id = '".$clienteId."' AND fecha_salida IS NULL AND registro_entrada = 1";
		$rs = mysql_query($sql,$conn);
		if (!$rs) {
			$array = array('Error'=>'No registra crearRegistroSalida ');
		
		}

		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}



	$server->register("obtenerRegistrosPorFechas",
		 array('parametros'=>'xsd:string'),
		array("return"=>"xsd:string"),
		$url);

	function obtenerRegistrosPorFechas($parametros)
	{
		$parametros = json_decode($parametros,true);
		$conn = conexionBD();
			$sql = "SELECT reg.cobro,reg.minutos,clientes.placa,grupo.nombre AS grupo from registro_estacionamiento AS reg 
				INNER JOIN clientes ON clientes.id = reg.clientes_id 
				INNER JOIN clientes_grupo AS grupo ON grupo.id = clientes.id 
				WHERE reg.fecha_entrada BETWEEN '".$parametros['fecha_inicial']."' AND '".$parametros['fecha_final']."'";
		$array = array('Error'=>'No se encuentra registros con las fechas relacionadas');
		$rs = mysql_query($sql,$conn);
		$totalCobro = 0;
		$totalCarros = 0;
		while($row = mysql_fetch_array($rs))
		{
			$array[] = $row;
			$totalCobro+= $row['cobro'];
			$totalCarros++;
		}

		if($totalCobro > 0){
			$array['totalCobro'] = $totalCobro;
			$array['totalCarros'] = $totalCarros;
		}
		return json_encode($array,JSON_UNESCAPED_UNICODE);
	}

		if(!isset($HTTP_RAW_POST_DATA))
		$HTTP_RAW_POST_DATA = file_get_contents('php://input');
		$server->service($HTTP_RAW_POST_DATA);	

?>