<?php

	include("../lib/nusoap.php");
	$url = "http://localhost/APITEST/servicio/servicio.php";
	$cliente = new nusoap_client($url."?wsdl","wsdl");

	$parametros = array('placa' =>'7777','clientes_grupo_id'=>'10');

	$registros = $cliente->call('crearRegistrosCliente',
				array('parametros'=>json_encode($parametros)),
				'uri:'.$url);


	if($cliente->fault){
		echo "Error";
		print_r($registros);
	}else{

		if($cliente->getError()){
			echo "<b>eRror: ".$cliente->getError()."</b>";
		}else{
			echo "<pre>";
			print_r(json_decode($registros));
			echo "</pre>";
		}

	}
	

