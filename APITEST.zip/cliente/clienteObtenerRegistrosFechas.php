<?php

	include("../lib/nusoap.php");
	$url = "http://localhost/APITEST/servicio/servicio.php";
	$cliente = new nusoap_client($url."?wsdl","wsdl");
	$parametros = array('fecha_inicial' =>'2020-12-31 00:00:00','fecha_final'=>'2021-12-31 00:00:00');

	$registros = $cliente->call('obtenerRegistrosPorFechas',
				array('parametros'=>json_encode($parametros)),
				'uri:'.$url);


	if($cliente->fault){
		echo "Error";
		print_r($registros);
	}else{

		if($cliente->getError()){
			echo "<b>eRror: ".$cliente->getError()."</b>";
		}else{
			echo "<pre>";
			print_r(json_decode($registros));
			echo "</pre>";
		}

	}
	

