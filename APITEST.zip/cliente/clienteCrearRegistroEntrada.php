<?php

	include("../lib/nusoap.php");
	$url = "http://localhost/APITEST/servicio/servicio.php";
	$cliente = new nusoap_client($url."?wsdl","wsdl");
	$fecha_entrada = date('Y-m-d H:i:s');
	$parametros = array('placa' =>'78945612','fecha_entrada'=>$fecha_entrada);

	$registros = $cliente->call('crearRegistroEntrada',
				array('parametros'=>json_encode($parametros)),
				'uri:'.$url);


	if($cliente->fault){
		echo "Error";
		print_r($registros);
	}else{

		if($cliente->getError()){
			echo "<b>eRror: ".$cliente->getError()."</b>";
		}else{
			echo "<pre>";
			print_r(json_decode($registros));
			echo "</pre>";
		}

	}
	

