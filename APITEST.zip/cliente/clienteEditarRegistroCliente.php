<?php

	include("../lib/nusoap.php");
	$url = "http://localhost/APITEST/servicio/servicio.php";
	$cliente = new nusoap_client($url."?wsdl","wsdl");
	$parametros = array('placa_actual' =>'5555','placa'=>'8888','activo'=>'1','clientes_grupo_id'=>'1');

	$registros = $cliente->call('editarRegistrosCliente',
				array('parametros'=>json_encode($parametros)),
				'uri:'.$url);

	if($cliente->fault){
		echo "Error";
		print_r($registros);
	}else{

		if($cliente->getError()){
			echo "<b>eRror: ".$cliente->getError()."</b>";
		}else{
			echo "<pre>";
			print_r(json_decode($registros));
			echo "</pre>";
		}

	}
