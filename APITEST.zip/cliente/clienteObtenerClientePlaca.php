<?php

	include("../lib/nusoap.php");
	$url = "http://localhost/APITEST/servicio/servicio.php";
	$cliente = new nusoap_client($url."?wsdl","wsdl");

	$placa = '456789';

	$registros = $cliente->call('obtenerRegistrosClientePlaca',
				array('placa'=>$placa),
				'uri:'.$url);


	if($cliente->fault){
		echo "Error";
		print_r($registros);
	}else{

		if($cliente->getError()){
			echo "<b>eRror: ".$cliente->getError()."</b>";
		}else{
			echo "<pre>";
			print_r(json_decode($registros));
			echo "</pre>";
		}

	}
	

