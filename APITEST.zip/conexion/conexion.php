<?php
	function conexionBD()
	{
		$conectar = mysql_connect("localhost","root","") or die(mysql_error());
		mysql_select_db("apitest",$conectar);
		return($conectar);

	}